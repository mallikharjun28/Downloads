﻿function RTE_DD_GetMenuFrame() {
    var ifmMenu = null;
    var elemMenu = RTE_DD_GetMenuElement();
    if (null != elemMenu) {
        if (document.frames.length > 0) {
            ifmMenu = document.frames[g_strRTETextEditorPullDownMenuID];
        }
        else {
            if ((document.parentWindow != null) && (document.parentWindow.frames != null)) {
                ifmMenu = document.parentWindow.parent.document.frames[g_strRTETextEditorPullDownMenuID];
            }
        }
    }
    if (null == ifmMenu) {
        if (g_fRTEFirstCallToGetMenu) {
            g_fRTEFirstCallToGetMenu = false;
            return null;
        }
    }
    return ifmMenu;
}

function RTE_GetEditorIFrame(strBaseElementID) {
    var ifmEditor = null;
    var doc = document;
    if ((null != doc.frames) && (doc.frames.length == 0) && (doc.parentWindow.parent != null)) {
        doc = doc.parentWindow.parent.document;
    }
    if ((null != doc.frames) && (doc.frames.length > 0)) {
        var ifmContainer = doc.getElementById(RTE_GetEditorIFrameID(strBaseElementID));
        if (ifmContainer != null) {
            ifmEditor = doc.frames[RTE_GetEditorIFrameID(strBaseElementID)];
        }
    }
    return ifmEditor;
}