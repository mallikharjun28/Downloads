﻿ExecuteOrDelayUntilScriptLoaded($, "sp.js");

var navIsDisplayed = true;
var isDialog = false;
$(document).ready(function () {
    $(".qlexpander.flip").click(function () {
        //alert("navIsDisplayed = "+navIsDisplayed);

        if (navIsDisplayed) {
            $(".panel").toggle();
            // alert("navIsDisplayed is being set to false");
            $("#MSO_ContentTable").css("margin-left", '4px');
            navIsDisplayed = false;
            $("#qlAccordian").prop("title", "→");
        }
        else {
            $(".panel").toggle();
            //alert("navIsDisplayed is being set to true");
            $("#MSO_ContentTable").css("margin-left", '155px');
            navIsDisplayed = true;
            $("#qlAccordian").prop("title", "←");
        }
        return false;
    });
    var htmlClass = $('html').attr('class');
    // alert('htmlClass = ' + htmlClass);
    if (htmlClass.indexOf('ms-dialog') != -1) {
        $('#qlAccordian').hide();
    }
    else {
        $('#qlAccordian').show();
    }

});

