﻿function doit(){
	alert("Hi there ... this loaded from the js SiteAssets Folder");
}
